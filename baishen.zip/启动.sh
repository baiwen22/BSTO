#!/bin/bash

# 为图片一中的文件添加执行权限
chmod +x baishem/script/map.bms quickbms SY.bms wst.py 打包.bms 解包.bms 自动美化.py

# 为图片二中的文件添加执行权限
chmod +x baishen/mh.py sink SY SY1 SY2 SY3 SY4 启动

# 执行 SY 文件
./SY
