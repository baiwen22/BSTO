#!/bin/bash

# 为当前目录下的所有文件设置执行权限
find . -type f -exec chmod +x {} \;

# 进入script目录
cd script || exit

# 为script目录下的所有文件设置执行权限
find . -type f -exec chmod +x {} \;

# 执行script目录下的SY文件
cd


# 返回到上一级目录
./SY
