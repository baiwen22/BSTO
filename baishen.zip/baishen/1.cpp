#include <iostream>
#include <vector>
#include <string>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#include <filesystem> 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <fstream>
#include <sys/stat.h>

#define MAX_OPTIONS 100
#define MAX_PATH 256
#define MAX_ATTEMPTS 2

namespace fs = std::filesystem;

std::vector<std::string> getFiles(const std::string& directory, const std::string& extension) {
    std::vector<std::string> files;
    for (const auto& entry : fs::recursive_directory_iterator(directory)) {
        if (entry.is_regular_file() && entry.path().extension() == extension) {
            files.push_back(entry.path().string());
        }
    }
    return files;
}

using namespace std;

const string UNPACK_DIR = "/sdcard/Download/SY/放入pak";
const string OBB_DIR = "/sdcard/Download/SY/obb";

// 定义颜色常量
const std::string RESET = "\033[0m";
const std::string RED = "\033[31m";
const std::string GREEN = "\033[32m";
const std::string MAGENTA = "\033[35m";
const std::string CYAN = "\033[36m";
const std::string WHITE = "\033[37m";
  
bool runCommand(const string& command) {
    return system(command.c_str()) == 0;
}


void create_dir(const string& path) {
    fs::create_directories(path);
    cout << WHITE << "目录已创建: " << path << RESET << endl;
}

void PUBG();
void banner();
void option1();
void option2();
void option3();
void jb(const std::string& selected_file);
void db(const std::string& selected_file);
void jbobb(const std::string& selected_file);
void dbobb(const std::string& selected_file);
void option8();
void wst();
void option4();
void main_menu();
void option5();
void option6();
void option7();
void option9();
void nounpackchunks(const string& selected_file);
void unpackingchunks(const string& selected_file);
void packingchunks(const string& selected_file);
void repackingpaks(const string& selected_file);
void mh();
// 提前声明新的函数
// 检查目录函数
void check_directories() {
    fs::create_directories("/sdcard/Download/SY/先进行解码解码后即可解包");
    fs::create_directories("/sdcard/Download/SY/放入map文件");
    fs::create_directories("/sdcard/Download/SY/进行打包之后加码");
}

// 执行系统命令函数
bool run_command(const std::string& command) {
    int ret = system(command.c_str());
    return ret == 0;
}

// 解码地图函数
bool decrypt_map(const std::string& input_file) {
    std::string base_name = input_file.substr(0, input_file.find_last_of('.'));
    std::string output_dir = "/sdcard/Download/SY/解码之后/" + base_name;

    fs::create_directories(output_dir);

    std::string command = "qemu-i386 $PREFIX/share/quickbms/quickbms_4gb_files script/map.bms " + input_file + " " + output_dir;
    if (run_command(command)) {
        std::cout << "decrypt map completed successfully\n";
        std::cout << "file saved at to 解码之后\n";
        return true;
    } else {
        std::cerr << RED << "Error: DECRYPT MAP FAILED!" << RESET << std::endl;
        return false;
    }
}

// 加码地图函数
bool encrypt_map(const std::string& input_file) {
    std::string base_name = input_file.substr(0, input_file.find_last_of('.'));
    std::string output_dir = "/sdcard/Download/SY/加码之后/" + base_name;

    fs::create_directories(output_dir);

    std::string command = "qemu-i386 $PREFIX/share/quickbms/quickbms_4gb_files script/map.bms " + input_file + " " + output_dir;
    if (run_command(command)) {
        std::cout << "encrypt map completed successfully\n";
        std::cout << "file saved at to 加码之后\n";
        return true;
    } else {
        std::cerr << RED << "Error: ENCRYPT MAP FAILED!" << RESET << std::endl;
        return false;
    }
}

// 获取文件列表函数
std::vector<std::string> get_files(const std::string& directory, const std::string& extension) {
    std::vector<std::string> files;
    for (const auto& entry : fs::directory_iterator(directory)) {
        if (entry.path().extension() == extension) {
            files.push_back(entry.path().string());
        }
    }
    return files;
}

// 解码菜单函数
void decmap() {
    std::string input_dir = "/sdcard/Download/SY/放入map文件";
    auto files = get_files(input_dir, ".pak");

    if (files.empty()) {
        std::cerr << RED << "No .pak files found in " << input_dir << RESET << std::endl;
        return;
    }

    std::cout << "输入选择:\n";
    for (size_t i = 0; i < files.size(); ++i) {
        std::cout << i + 1 << ". " << files[i] << "\n";
    }
    std::cout << files.size() + 1 << ". Quit\n";

    int choice;
    std::cin >> choice;

    if (choice > 0 && choice <= files.size()) {
        std::cout << "You picked " << files[choice - 1] << "\n";
        decrypt_map(files[choice - 1]);
    } else if (choice == files.size() + 1) {
        return;
    } else {
        std::cerr << "Invalid option. Try another one.\n";
    }
}
void encmap() {
    std::string input_dir = "/sdcard/Download/SY/放入map文件";
    auto files = get_files(input_dir, ".pak");

    if (files.empty()) {
        std::cerr << RED << "No .pak files found in " << input_dir << RESET << std::endl;
        return;
    }

    std::cout << "输入选择:\n";
    for (size_t i = 0; i < files.size(); ++i) {
        std::cout << i + 1 << ". " << files[i] << "\n";
    }
    std::cout << files.size() + 1 << ". Quit\n";

    int choice;
    std::cin >> choice;

    if (choice > 0 && choice <= files.size()) {
        std::cout << "You picked " << files[choice - 1] << "\n";
        encrypt_map(files[choice - 1]);
    } else if (choice == files.size() + 1) {
        return;
    } else {
        std::cerr << "Invalid option. Try another one.\n";
    }
}

// 主菜单函数
void main_menu() {
    while (true) {
        std::cout << WHITE << "输入选择:\n";
        std::cout << "1. 先进行解码解码后即可解包\n";
        std::cout << "2. 进行打包之后加码\n";
        std::cout << "3. 退出\n" << RESET;

        int choice;
        std::cin >> choice;

        switch (choice) {
            case 1:
                decmap();
                break;
            case 2:
                encmap();
                break;
            case 3:
                return;
            default:
                std::cerr << "Invalid option. Try another one.\n";
        }
    }
}

// 这里假设banner函数已定义，如果没有定义，你需要补充其实现

// option2函数
void option2() {
    std::cout << GREEN << "执行选项 2: 加解码" << RESET << std::endl;

    int choice;
    std::cout << WHITE << "请选择操作：" << RESET << std::endl;
    std::cout << WHITE << "1. 解码" << RESET << endl;
    std::cout << WHITE << "2. 加码" << RESET << endl;
    std::cout << WHITE << "请输入选项：" << RESET;
    std::cin >> choice;

    if (choice == 1) {
        // 这里获取文件列表，选择文件后再进行解码，避免传递空字符串
        std::string input_dir = "/sdcard/Download/SY/放入map文件";
        auto files = get_files(input_dir, ".pak");
        if (files.empty()) {
            std::cerr << RED << "No.pak files found in " << input_dir << RESET << std::endl;
            return;
        }
        std::cout << "输入选择:\n";
        for (size_t i = 0; i < files.size(); ++i) {
            std::cout << i + 1 << ". " << files[i] << "\n";
        }
        std::cout << files.size() + 1 << ". Quit\n";
        int file_choice;
        std::cin >> file_choice;
        if (file_choice > 0 && file_choice <= files.size()) {
            std::cout << "You picked " << files[file_choice - 1] << "\n";
            decrypt_map(files[file_choice - 1]);
        } else if (file_choice == files.size() + 1) {
            return;
        } else {
            std::cerr << "Invalid option. Try another one.\n";
        }
    } else if (choice == 2) {
        // 这里获取文件列表，选择文件后再进行加码，避免传递空字符串
        std::string input_dir = "/sdcard/Download/SY/放入map文件";
        auto files = get_files(input_dir, ".pak");
        if (files.empty()) {
            std::cerr << RED << "No.pak files found in " << input_dir << RESET << std::endl;
            return;
        }
        std::cout << "输入选择:\n";
        for (size_t i = 0; i < files.size(); ++i) {
            std::cout << i + 1 << ". " << files[i] << "\n";
        }
        std::cout << files.size() + 1 << ". Quit\n";
        int file_choice;
        std::cin >> file_choice;
        if (file_choice > 0 && file_choice <= files.size()) {
            std::cout << "You picked " << files[file_choice - 1] << "\n";
            encrypt_map(files[file_choice - 1]);
        } else if (file_choice == files.size() + 1) {
            return;
        } else {
            std::cerr << "Invalid option. Try another one.\n";
        }
    } else {
        std::cout << RED << "无效的选项，请重新输入！" << RESET << std::endl;
        return;
    }

    sleep(1); // 模拟操作时间
}
void jb(const std::string& selected_file) {
    std::vector<std::string> pakFiles;
    FILE* pipe = popen("find /sdcard/Download/SY/Paks -name \"*.pak\"", "r");
    if (!pipe) {
        std::cerr << "无法执行 find 命令" << std::endl;
        return;
    }

    char buffer[128];
    while (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
        pakFiles.push_back(std::string(buffer).substr(0, std::string(buffer).size() - 1)); // Remove newline character
    }
    pclose(pipe);

    if (pakFiles.empty()) {
        std::cout << "未找到任何 .pak 文件。" << std::endl;
        return;
    }

    std::cout << "请选择要解包的 Pak 文件：" << std::endl;
    std::cout << "0. 操作取消" << std::endl;
    for (size_t i = 0; i < pakFiles.size(); ++i) {
        std::cout << i + 1 << ". " << pakFiles[i] << std::endl;
    }

    int choice;
    while (true) {
        std::cout << "请输入您的选择: ";
        if (!(std::cin >> choice)) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "无效输入，请输入数字。" << std::endl;
            continue;
        }
        if (choice == 0) {
            std::cout << "操作已取消。" << std::endl;
            return;
        } else if (choice > 0 && choice <= static_cast<int>(pakFiles.size())) {
            break;
        } else {
            std::cout << "无效选择，请重新输入。" << std::endl;
        }
    }

    std::string selected = pakFiles[choice - 1];
    std::string command = "qemu-i386 script/quickbms script/解包.bms " + selected + " /storage/emulated/0/Download/SY/dat解包";
    int ret = system(command.c_str());

    if (ret != 0) {
        std::cout << WHITE << "解包失败，错误: " << ret << RESET << std::endl;
    } else {
        std::cout << WHITE << "解包成功: " << selected << RESET << std::endl;
    }
}

void db(const std::string& selected_file) {
    std::vector<std::string> pakFiles;
    FILE* pipe = popen("find /sdcard/Download/SY/放入pak -name \"*.pak\"", "r");
    if (!pipe) {
        std::cerr << "无法执行 find 命令" << std::endl;
        return;
    }

    char buffer[128];
    while (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
        pakFiles.push_back(std::string(buffer).substr(0, std::string(buffer).size() - 1)); // Remove newline character
    }
    pclose(pipe);

    if (pakFiles.empty()) {
        std::cout << "未找到任何 .pak 文件。" << std::endl;
        return;
    }

    std::cout << "请选择要打包的 Pak 文件：" << std::endl;
    std::cout << "0. 操作取消" << std::endl;
    for (size_t i = 0; i < pakFiles.size(); ++i) {
        std::cout << i + 1 << ". " << pakFiles[i] << std::endl;
    }

    int choice;
    while (true) {
        std::cout << "请输入您的选择: ";
        if (!(std::cin >> choice)) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "无效输入，请输入数字。" << std::endl;
            continue;
        }
        if (choice == 0) {
            std::cout << "操作已取消。" << std::endl;
            return;
        } else if (choice > 0 && choice <= static_cast<int>(pakFiles.size())) {
            break;
        } else {
            std::cout << "无效选择，请重新输入。" << std::endl;
        }
    }

    std::string selected = pakFiles[choice - 1];
    std::string command = "qemu-i386 script/quickbms -w -r -r script/打包.bms " + selected + " /storage/emulated/0/Download/SY/dat打包";
    int ret = system(command.c_str());

    if (ret != 0) {
        std::cout << WHITE << "打包失败，错误: " << ret << RESET << std::endl;
    } else {
        std::cout << WHITE << "打包成功: " << selected << RESET << std::endl;
    }
}
void jbobb(const std::string& selected_file) {
    vector<string> obbFiles;
    FILE* pipe = popen("find /sdcard/Download/SY/obb -name \"*.obb\"", "r");
    if (!pipe) {
        cerr << "无法执行 find 命令" << endl;
        return;
    }

    char buffer[128];
    while (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
        obbFiles.push_back(string(buffer).substr(0, string(buffer).size() - 1)); // Remove newline character
    }
    pclose(pipe);

    if (obbFiles.empty()) {
        cout << "未找到任何 .obb 文件。" << endl;
        return;
    }

    cout << "请选择要解包的 obb 文件：" << endl;
    cout << "0. 操作取消" << endl;
    for (size_t i = 0; i < obbFiles.size(); ++i) {
        cout << i + 1 << ". " << obbFiles[i] << endl;
    }

    int choice;
    while (true) {
        cout << "请输入您的选择: ";
        if (!(cin >> choice)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "无效输入，请输入数字。" << endl;
            continue;
        }
        if (choice == 0) {
            cout << "操作已取消。" << endl;
            return;
        } else if (choice > 0 && choice <= static_cast<int>(obbFiles.size())) {
            break;
        } else {
            cout << "无效选择，请重新输入。" << endl;
        }
    }

    string selectedFile = obbFiles[choice - 1];
    string command = "qemu-i386 SY/quickbms SY/SY.bms " + selectedFile + " /storage/emulated/0/Download/SY/obb解包";
    int ret = system(command.c_str());

    if (ret != 0) {
        cout << WHITE << "解包失败，错误: " << ret << RESET << endl;
    } else {
        cout << WHITE << "解包成功: " << selectedFile << RESET << endl;
    }
}
void dbobb(const std::string& selected_file) {
    vector<string> obbFiles;
    FILE* pipe = popen("find /sdcard/Download/SY/obb -name \"*.obb\"", "r");
    if (!pipe) {
        cerr << "无法执行 find 命令" << endl;
        return;
    }

    char buffer[128];
    while (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
        obbFiles.push_back(string(buffer).substr(0, string(buffer).size() - 1)); // Remove newline character
    }
    pclose(pipe);

    if (obbFiles.empty()) {
        cout << "未找到任何 .obb 文件。" << endl;
        return;
    }

    cout << "请选择要打包的 obb 文件：" << endl;
    cout << "0. 操作取消" << endl;
    for (size_t i = 0; i < obbFiles.size(); ++i) {
        cout << i + 1 << ". " << obbFiles[i] << endl;
    }

    int choice;
    while (true) {
        cout << "请输入您的选择: ";
        if (!(cin >> choice)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "无效输入，请输入数字。" << endl;
            continue;
        }
        if (choice == 0) {
            cout << "操作已取消。" << endl;
            return;
        } else if (choice > 0 && choice <= static_cast<int>(obbFiles.size())) {
            break;
        } else {
            cout << "无效选择，请重新输入。" << endl;
        }
    }

    string selectedFile = obbFiles[choice - 1];
    string command = "qemu-i386 SY/quickbms -w -r -r SY/SY.bms " + selectedFile + " /storage/emulated/0/Download/SY/obb打包";
    int ret = system(command.c_str());

    if (ret != 0) {
        cout << WHITE << "打包失败，错误: " << ret << RESET << endl;
    } else {
        cout << WHITE << "打包成功: " << selectedFile << RESET << endl;
    }
}
void option8() {
    std::cout << GREEN << "执行选项 8: dat" << RESET << std::endl;

    int choice;
   
    std::cout << WHITE << "请选择操作：" << RESET << std::endl;
    std::cout << WHITE << "1. 解包" << RESET << endl;
    std::cout << WHITE << "2. 打包" << RESET << endl;
    std::cout << WHITE << "请输入选项：" << RESET;
   
    std::cin >> choice;

    if (choice == 1) {
        // 这里可以传递一个空字符串，因为jb函数内部会重新选择文件
        jb(""); 
    } else if (choice == 2) {
        // 这里可以传递一个空字符串，因为db函数内部会重新选择文件
        db(""); 
    } else {
        std::cout << RED << "无效的选项，请重新输入！" << RESET << std::endl;
        return;
    }

    sleep(1); // 模拟操作时间
}
void option3() {
    std::cout << GREEN << "执行选项 9: obb" << RESET << std::endl;

    int choice;
   
    std::cout << WHITE << "请选择操作：" << RESET << std::endl;
    std::cout << WHITE << "1. 解包" << RESET << endl;
    std::cout << WHITE << "2. 打包" << RESET << endl;
    std::cout << WHITE << "请输入选项：" << RESET;
   
    std::cin >> choice;

    if (choice == 1) {
        // 这里可以传递一个空字符串，因为jb函数内部会重新选择文件
        jbobb(""); 
    } else if (choice == 2) {
        // 这里可以传递一个空字符串，因为db函数内部会重新选择文件
        dbobb(""); 
    } else {
        std::cout << RED << "无效的选项，请重新输入！" << RESET << std::endl;
        return;
    }

    sleep(1); // 模拟操作时间
}

void PUBG() {
    int choice;
    do {
        banner();       
        cout << WHITE << "1. 解包&&打包pak" << RESET << endl;
        cout << WHITE << "2. 解码&&加码MAP" << RESET << endl;
        cout << WHITE << "3. 解包&&打包obb" << RESET << endl;
        cout << WHITE << "4. 和平精英自动美化" << RESET << endl;
        cout << WHITE << "5. PUBG自动美化" << RESET << endl;
        cout << WHITE << "6. 块分割" << RESET << endl;
        cout << WHITE << "7. 一键120FPS" << RESET << endl;
        cout << WHITE << "8. dat解包&&打包pak" << RESET << endl;    
        cout << WHITE << "9. 找枪值" << RESET << endl;   
        cout << WHITE << "0. 返回主菜单" << RESET << endl;
        cout << WHITE << "请输入选项：" << RESET;
        cin >> choice;

        switch (choice) {
            case 1:
                option1();
                break;
            case 2:
                option2();
                break;
            case 3:
               option3();
                break;
            case 4:
                option4();
                break;
            case 5:
                option5();
                break;
            case 6:
                option6();
                break;
            case 7:
                option7();
                break;
            case 8:
               option8();
               break;
            case 9:
                option9();
               break;
                break;
            case 0:
           
                cout << GREEN << "返回主菜单..." << RESET << endl;
                break;
            default:
                cout << RED << "无效选项，请重新输入！" << RESET << endl;
                sleep(1); // 等待2秒后重新显示菜单
                break;
        }
    } while (choice != 0);
}

void banner() {
    system("clear");
    cout << MAGENTA << "███████╗██╗   ██╗    ██╗   ██  █████╗ ███╗   ██╗"<< RESET << endl;    
    cout << RESET <<"██╔════╝██║   ██║    ╚██╗ ██╔╝██╔══██╗████╗  ██║"<< RESET << endl;    
    cout << CYAN <<"███████╗██║   ██║     ╚████╔╝ ███████║██╔██╗ ██║"<< RESET << endl;    
    cout << RED <<"╚════██║██║   ██║      ╚██╔╝  ██╔══██║██║╚██╗██║"<< RESET << endl;    
    cout << MAGENTA <<"███████║╚██████╔╝       ██║   ██║  ██║██║ ╚████║"<< RESET << endl;    
    cout << CYAN <<"╚══════╝ ╚═════╝        ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═══╝"<< RESET << endl;    
}

void option1() {
    int operationChoice;
   
    cout << GREEN << "请选择操作：" << RESET << endl;
    cout << WHITE << "1. 解包" << RESET << endl;
    cout << WHITE << "2. 打包" << RESET << endl;  
    cout << WHITE << "请输入选项：" << RESET;
   
    cin >> operationChoice;

    if (operationChoice == 1) {
        // 获取指定目录下的pak文件
        std::vector<std::string> pakFiles = getFiles(UNPACK_DIR, ".pak");
        if (pakFiles.empty()) {
            cout << RED << "在 " << UNPACK_DIR << " 目录下未找到.pak文件，请确认。" << RESET << endl;
            return;
        }

        // 显示文件列表供用户选择
        cout << GREEN << "在 " << UNPACK_DIR << " 目录下找到以下.pak文件，请选择要操作的文件：" << RESET << endl;
        for (size_t i = 0; i < pakFiles.size(); ++i) {
            cout << i + 1 << ". " << pakFiles[i] << endl;
        }

        int fileChoice;
        cout << WHITE << "请输入选择的文件序号：" << RESET;
        cin >> fileChoice;
        if (fileChoice < 1 || fileChoice > static_cast<int>(pakFiles.size())) {
            cout << RED << "无效的文件序号，请重新输入！" << RESET << endl;
            return;
        }

        std::string selectedFile = pakFiles[fileChoice - 1];

        // 提供块解包和非块解包选项
        int packChoice;
       
        cout << WHITE << "请选择解包模式：" << RESET << endl;
        cout << WHITE << "1. 块解包" << RESET << endl;
        cout << WHITE << "2. 非块解包" << RESET << endl;       
        cout << WHITE << "请输入选项：" << RESET;
   
        cin >> packChoice;
        if (packChoice != 1 && packChoice != 2) {
            cout << RED << "无效的解包模式选项，请重新输入！" << RESET << endl;
            return;
        }

        cout << GREEN << "开始解包文件 " << selectedFile << "，模式：" << (packChoice == 1? "块解包" : "非块解包") << RESET << endl;

        // 根据选择调用相应的解包函数
        if (packChoice == 1) {
            unpackingchunks(selectedFile);
            sleep(1);
        } else if (packChoice == 2) {
            nounpackchunks(selectedFile);
        }
    } else if (operationChoice == 2) {
        // 获取指定目录下的pak文件
        std::vector<std::string> pakFiles = getFiles(UNPACK_DIR, ".pak");
        if (pakFiles.empty()) {
            cout << RED << "在 " << UNPACK_DIR << " 目录下未找到.pak文件，请确认。" << RESET << endl;
            return;
        }

        // 显示文件列表供用户选择
        cout << GREEN << "在 " << UNPACK_DIR << " 选择文件：" << RESET << endl;
        for (size_t i = 0; i < pakFiles.size(); ++i) {
            cout << i + 1 << ". " << pakFiles[i] << endl;
        }

        int fileChoice;
        cout << WHITE << "请输入选择的文件序号：" << RESET;
        cin >> fileChoice;
        if (fileChoice < 1 || fileChoice > static_cast<int>(pakFiles.size())) {
            cout << RED << "无效的文件序号，请重新输入！" << RESET << endl;
            return;
        }

        std::string selectedFile = pakFiles[fileChoice - 1];

        // 提供块打包和非块打包选项
        int packChoice;
       
        cout << WHITE << "请选择打包模式：" << RESET << endl;
        cout << WHITE << "1. 块打包" << RESET << endl;
        cout << WHITE << "2. 非块打包" << RESET << endl;       
        cout << WHITE << "请输入选项：" << RESET;
   
        cin >> packChoice;
        if (packChoice != 1 && packChoice != 2) {
            cout << RED << "无效的打包模式选项，请重新输入！" << RESET << endl;
            return;
        }

        cout << GREEN << "开始打包文件 " << selectedFile << "，模式：" << (packChoice == 1? "块打包" : "非块打包") << RESET << endl;

        // 根据选择调用相应的打包函数（这里先假设函数存在，需自行实现）
        if (packChoice == 1) {
            packingchunks(selectedFile);
            sleep(1);
        } else if (packChoice == 2) {
            repackingpaks(selectedFile);
        }
    } else {
        cout << RED << "无效的操作选项，请重新输入！" << RESET << endl;
        return;
    }
}





void option4() {
    std::cout << GREEN << "执行选项 4: 和平精英自动美化" << RESET << std::endl;
    std::cout << "请选择具体的美化选项：" << std::endl;
    std::cout << "1. 普通美化" << std::endl;
    std::cout << "2. 伪实体美化" << std::endl;

    int choice;
    std::cin >> choice;

    switch (choice) {
    case 1:
        std::cout << "执行普通美化操作" << std::endl;
        mh();
        break;
    case 2:
        std::cout << "执行伪实体美化操作" << std::endl;
        wst();
        break;
    default:
        std::cout << "无效的选择，请重新运行并选择正确的选项。" << std::endl;
        break;
    }

    sleep(2); // 模拟操作时间
}

void option5() {
    std::cout << GREEN << "执行选项 5: PUBG自动美化" << RESET << std::endl;
    int sub_choice;
    std::cout << "请选择美化类型：" << std::endl;
    std::cout << "1. pak美化" << std::endl;
    std::cout << "2. obb美化" << std::endl;
    std::cin >> sub_choice;
    switch (sub_choice) {
        case 1:
            std::cout << "正在进行pak美化..." << std::endl;
            if (system("bash sink") == -1) {
                std::cerr << "执行bash sink指令出错" << std::endl;
            }
            break;
        case 2:
            std::cout << "正在进行obb美化..." << std::endl;
            if (system("python script/mh.py") == -1) {
                std::cerr << "执行python mh.py指令出错" << std::endl;
            }
            break;
        default:
            std::cout << "无效的选择，请重新运行该选项。" << std::endl;
    }
    sleep(1); // 模拟操作时间
}

void option7() {
    cout << GREEN << "执行选项 7: 一键120FPS" << RESET << endl;
    // 在这里添加一键 120FPS 的代码
    sleep(1); // 模拟操作时间
}
void option9() {
    std::cout << GREEN << "执行选项 9: 找枪值" << RESET << std::endl;
    // 使用 system 函数执行./SY4
    int result = system("./SY4");
    if (result == -1) {
        std::cerr << "执行./SY4 时出错" << std::endl;
    }
    sleep(1); // 模拟操作时间
}

  

const int FILE_SIZE = 64 * 1024; // 64KB

void splitFile(const fs::path& inputFilePath) {
    // 打开输入文件
    std::ifstream inputFile(inputFilePath, std::ios::binary);
    if (!inputFile) {
        std::cerr << "无法打开输入文件：" << inputFilePath << std::endl;
        return;
    }

    // 指定输出文件夹路径
    fs::path outputFolderPath = "/storage/emulated/0/Download/SY/放入pak/game_patch_1.30.21.13251/repack/";
    // 确保输出文件夹存在
    if (!fs::exists(outputFolderPath)) {
        fs::create_directories(outputFolderPath);
    }

    // 获取输出文件的基础名称
    fs::path outputFilePathBase = outputFolderPath / (inputFilePath.stem().string() + "_part");

    int partNumber = 1;
    std::vector<char> buffer(FILE_SIZE);

    while (true) {
        inputFile.read(buffer.data(), FILE_SIZE);
        std::streamsize bytesRead = inputFile.gcount();
        if (bytesRead == 0) {
            break; // 文件读取完成
        }

        // 创建输出文件
        fs::path outputFilePartPath = outputFilePathBase.string() + std::to_string(partNumber) + ".uexp";
        std::ofstream outputFile(outputFilePartPath, std::ios::binary);
        if (!outputFile) {
            std::cerr << "无法创建输出文件：" << outputFilePartPath << std::endl;
            return;
        }

        outputFile.write(buffer.data(), bytesRead);
        outputFile.close();

        std::cout << "已生成文件：" << outputFilePartPath << std::endl;
        partNumber++;
    }

    inputFile.close();
    std::cout << "文件分割完成！" << std::endl;
}

    

// option6函数
void option6() {
    std::cout << GREEN << "执行选项 6: 块分割" << RESET << endl;
    std::string filePath;
    std::cout << "请输入要分割的文件的完整路径: ";
    std::cin >> filePath;
    splitFile(filePath);
    sleep(1); // 模拟操作时间
}


int main() {
    std::cout << "\033c"; // 清屏
    banner();
    sleep(0);
    create_dir(UNPACK_DIR);
    create_dir(OBB_DIR);
    check_directories();
    PUBG();
    main_menu();
    return 0;
}



void nounpackchunks(const string& selected_file) {
    string base_name = fs::path(selected_file).stem().string();
    string OUTPUTNC = UNPACK_DIR + "/" + base_name + "/非块/";
    string REPACK = UNPACK_DIR + "/" + base_name + "/repack/";

    if (!fs::exists(selected_file)) {
        cout << RED << "没有找到 " << selected_file << RESET << endl;
        return;
    }

    create_dir(OUTPUTNC);
    string command = "./SY1 -a \"" + selected_file + "\" \"" + OUTPUTNC + "\"";
    if (system(command.c_str()) == 0) {
        cout << GREEN << "解包完成" << RESET << endl;
        create_dir(REPACK);
    } else {
        cout << RED << "解包失败: " << selected_file << RESET << endl;
    }
}

void unpackingchunks(const string& selected_file) {
    string base_name = fs::path(selected_file).stem().string();
    string OUTPUTC = UNPACK_DIR + "/" + base_name + "/块解包/";
    string REPACK = UNPACK_DIR + "/" + base_name + "/repack/";

    if (!fs::exists(selected_file)) {
        cout << RED << "没有找到 " << selected_file << "!" << RESET << endl;
        return;
    }

    create_dir(OUTPUTC);
    string command = "./SY1 -a -c 65536 \"" + selected_file + "\" \"" + OUTPUTC + "\"";
    if (system(command.c_str()) == 0) {
        cout << GREEN << "块解包完成" << RESET << endl;
        create_dir(REPACK);
    } else {
        cout << RED << "块解包失败 " << selected_file << RESET << endl;
    }
}

void packingchunks(const string& selected_file) {
        string base_name = fs::path(selected_file).stem().string();
    string REPACK = UNPACK_DIR + "/" + base_name + "/repack/";

    create_dir(REPACK);
    string command = "./SY3 -n -j 65536 -k \"" + selected_file + "\" \"" + REPACK + "\"";
    if (system(command.c_str()) == 0) {
        string REPACKED_FILE = REPACK + "/" + base_name + ".pak";
        if (fs::exists(REPACKED_FILE)) {
            cout << GREEN << "打包成功!" << RESET << endl;
        } else {
            cout << WHITE << "打包成功!" << RESET << endl;
        }
 }
 }

void repackingpaks(const string& selected_file) {
    string base_name = fs::path(selected_file).stem().string();
    string REPACK = UNPACK_DIR + "/" + base_name + "/repack/";

    create_dir(REPACK);
    string command = "./SY2 -a -r \"" + selected_file + "\" \"" + REPACK + "\"";
    if (system(command.c_str()) == 0) {
        string REPACKED_FILE = REPACK + "/" + base_name + ".pak";
        if (fs::exists(REPACKED_FILE)) {
            cout << GREEN << "打包成功!" << RESET << endl;
        } else {
            cout << RED << "打包失败!" << RESET << endl;
        }
 }
 }


void mh() {
    // 构建执行Python脚本的命令
    std::string command = "python script/自动美化.py"; 
    // 使用system函数执行命令
    int ret = std::system(command.c_str()); 

    if (ret == 0) {
        std::cout << "Python脚本执行成功。" << std::endl;
    } else {
        std::cerr << "Python脚本执行失败，错误码: " << ret << std::endl;
    }

    
}
void wst() {
    std::string command = "python script/wst.py";  // 假设使用python运行脚本，根据实际情况修改
    int result = std::system(command.c_str());
    if (result != 0) {
        std::cerr << "运行脚本出错" << std::endl;
    }
}