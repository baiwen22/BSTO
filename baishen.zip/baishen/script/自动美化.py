import os
import struct


# 定义颜色常量
NOCOLOR = '\033[0m'
RED = '\033[1;31m'
GREEN = '\033[1;32m'
YELLOW = '\033[1;33m'
BLUE = '\033[0;34m'
LIGHTBLUE = '\033[1;34m'
WHITE = '\033[1;37m'


# 将十进制数转换为十六进制并反转
def DEC_to_HEX(decimal_number):
    hex_number = format(decimal_number, '08x')
    reversed_hex_number = ''.join([hex_number[i:i + 2] for i in range(len(hex_number) - 2, -1, -2)])
    print(f"{YELLOW}偏移 {decimal_number}转换为: {reversed_hex_number}{NOCOLOR}")
    return reversed_hex_number


# 将十六进制数转换为十进制
def HEX_to_DEC(hex_number):
    reversed_hex_number = ''.join([hex_number[i:i + 2] for i in range(len(hex_number) - 2, -1, -2)])
    return int(reversed_hex_number, 16)


# 修改文件十六进制函数
def modify_file_hex(file_path, A, B):
    search_seq1 = bytes.fromhex(A)
    search_seq2 = bytes.fromhex(B)
    offset_before_search_seq = 0

    try:
        with open(file_path, 'rb') as file:
            file_contents = file.read()
    except FileNotFoundError:
        print(f"{RED}错误：文件 {file_path} 未找到。{NOCOLOR}")
        return

    search_index1 = file_contents.find(search_seq1)
    search_index2 = file_contents.find(search_seq2)

    if search_index1 == -1:
        print(f"{RED}错误：未找到十六进制序列 {A}。{NOCOLOR}")
        return
    if search_index2 == -1:
        print(f"{RED}错误：未找到十六进制序列 {B}。{NOCOLOR}")
        return

    replace_index1 = search_index1 - offset_before_search_seq
    replace_index2 = search_index2 - offset_before_search_seq

    if replace_index1 < 0 or replace_index2 < 0:
        print(f"{RED}错误：偏移量导致替换位置超出文件开始位置。{NOCOLOR}")
        return

    print(f"{GREEN}第一个偏移位置及值: {hex(replace_index1)}: {' '.join(format(byte, '02x') for byte in file_contents[replace_index1:replace_index1 + 4])}{NOCOLOR}")
    print(f"{GREEN}第二个偏移位置及值: {hex(replace_index2)}: {' '.join(format(byte, '02x') for byte in file_contents[replace_index2:replace_index2 + 4])}{NOCOLOR}")

    new_contents = bytearray(file_contents)
    value_at_replace_index1 = new_contents[replace_index1:replace_index1 + 4]
    value_at_replace_index2 = new_contents[replace_index2:replace_index2 + 4]

    new_contents[replace_index1:replace_index1 + 4] = value_at_replace_index2
    new_contents[replace_index2:replace_index2 + 4] = value_at_replace_index1

    try:
        with open(file_path, 'wb') as outfile:
            outfile.write(new_contents)
    except IOError:
        print(f"{RED}错误：无法写入文件 {file_path}。{NOCOLOR}")
        return

    print(f"{GREEN}正在修改，修改完成{NOCOLOR}")


# 批量处理函数
def process_batch(file_path, code_list):
    for original_decimal, new_decimal in code_list:
        modify_file_hex(file_path, DEC_to_HEX(original_decimal), DEC_to_HEX(new_decimal))
        print(f"{LIGHTBLUE}------------------------------------------------------{NOCOLOR}")


def main():
    while True:
        print(f"{LIGHTBLUE}1. 修改美化{NOCOLOR}")
        choice = input("请输入选项：")
        if choice == '1':
            file_path = input(f"{RED}请输入要修改文件路径：{NOCOLOR}")
            txt_file_path = input(f"{LIGHTBLUE}请输入美化配置文件路径：{NOCOLOR}")

            try:
                code_list = []
                with open(txt_file_path, 'r') as txt_file:
                    for line in txt_file:
                        original_decimal, new_decimal = map(int, line.split())
                        code_list.append((original_decimal, new_decimal))
            except FileNotFoundError:
                print(f"{RED}错误：文件 {txt_file_path} 未找到。{NOCOLOR}")
                continue

            process_batch(file_path, code_list)
        else:
            print(f"{RED}无效选项，请重新输入。{NOCOLOR}")

        exit_choice = input(f"\n{WHITE}是否继续修改？(继续输入 Y，退出输入 N)：{NOCOLOR}")
        if exit_choice.lower() not in ['y', 'yes']:
            print(f"{WHITE}已退出。{NOCOLOR}")
            break


if __name__ == "__main__":
    main()
